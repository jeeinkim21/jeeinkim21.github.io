
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Nullptrs Office</title>
<link href="home.css" rel="stylesheet" type="text/css" />
<link rel="icon" type="image/x-icon" src="images/DoctorLogo.png">
</head>

<body>
  
  <div class="header">

  <a class="header-items" href="home.php"> <img src="images/DoctorLogo.png"  height="100px" alt="Doctor" class="header-items"> </a>
  <b><a class="header-items" href="doctors.php">Check Doctors</a> </b>
  <b><a class="header-items" href="medicine.php">Medicine</a> </b>
  <b><a class="header-items" href="Doctorconsult.php"> Doctor Consults</a></b>
  <b><a class="header-items" href="appointment.php">Appointments</a></b>

  </div>

  <div class="CheckDoctors">

   <div class="CheckDoctorsTab">
   <center><p>Here at Nullptrs Office we offer only the best and most trustowrthy doctors that give the best service to our patients. </p><center>
   <center><p><strong> Check the handful of doctors you can trust here: </strong></p></center>
   <center><button class="button button1" onclick="window.location.href='doctors.php'"  >Check Doctors!</button></center>
   </div>
   <div class="PicturesOfDoctors">
   <img src="images/Doctor-helping-elderly.jpeg" alt="DoctorTogether" class="header-items">
   </div>

  </div>
  
  <div class="footer">

  <img src="images/DoctorLogo.png" height="100px"alt="Doctor" class="header-items">

  </div>
</body>
